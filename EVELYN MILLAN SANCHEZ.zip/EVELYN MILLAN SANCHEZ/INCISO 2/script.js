const contenedor = document.getElementById("contenedor-tablas");

for (let i = 1; i <= 20; i++) {
    const tabla = document.createElement("div");
    tabla.classList.add("tabla");

    const titulo = document.createElement("h2");
    titulo.textContent = `Tabla del ${i}`;
    tabla.appendChild(titulo);

    for (let j = 1; j <= 10; j++) {
        const linea = document.createElement("p");
        linea.textContent = `${i} × ${j} = ${i * j}`;
        tabla.appendChild(linea);
    }

    contenedor.appendChild(tabla);
}