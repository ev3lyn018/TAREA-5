document.getElementById("boton").addEventListener("click", function() {
    let texto = document.getElementById("texto").value;
    let correo = document.getElementById("correo").value;
    let telefono = document.getElementById("telefono").value;
    let contraseña = document.getElementById("contraseña").value;
    let color = document.getElementById("color").value;

    console.log("boton presionado. texto ingresado: " + texto);
    console.log("boton presionado. telefono ingresado: " + telefono);
    console.log("boton presionado. correo ingresado: " + email);
    console.log("boton presionado. contraseña ingresada " + password);
    console.log("boton presionado. fecha ingresada " + date);

    document.getElementsByTagName("p")[1].innerHTML = "has ingresado: " + texto;
    document.getElementsByTagName("p")[2].innerHTML = "el telefono ingresado es: " + telefono;
    document.getElementsByTagName("p")[3].innerHTML = "el correo ingresado es: " + email;
    document.getElementsByTagName("p")[4].innerHTML = "la contraseña ingresada es: " + password;
    document.getElementsByTagName("body")[0].style.backgroundColor = color;
});